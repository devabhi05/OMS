</div>
<footer class="bg-light text-center text-muted py-3 mt-auto border-top">
  <div class="container">
    <small>&copy; <?php echo date('Y'); ?> Office Management System</small>
  </div>
</footer>

<!-- DataTables Bootstrap 5 CSS -->
<link rel="stylesheet" href="https://cdn.datatables.net/1.13.7/css/dataTables.bootstrap5.min.css">

<!-- jQuery DataTables core + Bootstrap 5 integration -->
<script src="https://cdn.datatables.net/1.13.7/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.13.7/js/dataTables.bootstrap5.min.js"></script>

<script>
  // Turn the Manager-Approved Completed Entries table into a jQuery DataTable
  document.addEventListener('DOMContentLoaded', function () {
    // Make sure jQuery and the table exist
    if (window.jQuery && $('#tasktable').length) {
      $('#tasktable').DataTable({
        // Keep the existing PHP sort order as default
        order: [],

        // Basic DataTables features
        paging: true,
        lengthChange: true,
        searching: true,
        ordering: true,
        info: true,
        autoWidth: false,

        // Disable sorting & searching on the Actions column (last column)
        columnDefs: [
          {
            targets: -1,          // last column = Actions
            orderable: false,
            searchable: false
          }
        ]
      });
    }
  });
</script>

</body>
</html>
