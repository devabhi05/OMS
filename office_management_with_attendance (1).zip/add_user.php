<?php
require_once 'config.php';
require_once 'auth.php';

require_login();
require_role(['admin']);

$pageTitle = 'Add User';

$full_name = '';
$username  = '';
$role      = 'employee';
$errors    = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $full_name = trim($_POST['full_name'] ?? '');
    $username  = trim($_POST['username'] ?? '');
    $password  = trim($_POST['password'] ?? '');
    $role      = trim($_POST['role'] ?? 'employee');

    $validRoles = ['admin', 'manager', 'employee'];

    if ($full_name === '') {
        $errors[] = 'Full name is required.';
    }
    if ($username === '') {
        $errors[] = 'Username is required.';
    }
    if ($password === '') {
        $errors[] = 'Password is required.';
    }
    if (!in_array($role, $validRoles, true)) {
        $errors[] = 'Invalid role selected.';
    }

    if (!$errors) {
        $stmt = $mysqli->prepare(
            "INSERT INTO users (full_name, username, password, role) VALUES (?,?,?,?)"
        );
        if (!$stmt) {
            $errors[] = 'Prepare failed: ' . $mysqli->error;
        } else {
            $stmt->bind_param('ssss', $full_name, $username, $password, $role);
            if ($stmt->execute()) {
                $stmt->close();
                $msg = urlencode('User created successfully.');
                header("Location: manage_users.php?msg={$msg}");
                exit;
            } else {
                if ($mysqli->errno === 1062) {
                    $errors[] = 'Username already exists.';
                } else {
                    $errors[] = 'Failed to create user: ' . $stmt->error;
                }
                $stmt->close();
            }
        }
    }
}

include 'header.php';
?>
<div class="mb-4">
  <h2>Add User</h2>
</div>

<?php if ($errors): ?>
<div class="alert alert-danger">
  <ul class="mb-0">
    <?php foreach ($errors as $e): ?>
      <li><?php echo htmlspecialchars($e); ?></li>
    <?php endforeach; ?>
  </ul>
</div>
<?php endif; ?>

<div class="card">
  <div class="card-header">
    <strong>New User Details</strong>
  </div>
  <div class="card-body">
    <form method="post" autocomplete="off">
      <div class="mb-3">
        <label class="form-label">Full Name</label>
        <input type="text" name="full_name" class="form-control"
               value="<?php echo htmlspecialchars($full_name); ?>" required>
      </div>

      <div class="mb-3">
        <label class="form-label">Username</label>
        <input type="text" name="username" class="form-control"
               value="<?php echo htmlspecialchars($username); ?>" required>
      </div>

      <div class="mb-3">
        <label class="form-label">Password</label>
        <input type="text" name="password" class="form-control" required>
        <div class="form-text">Plain text for now (you can change to password_hash later).</div>
      </div>

      <div class="mb-3">
        <label class="form-label">Role</label>
        <select name="role" class="form-select" required>
          <option value="admin"   <?php if ($role === 'admin') echo 'selected'; ?>>Admin</option>
          <option value="manager" <?php if ($role === 'manager') echo 'selected'; ?>>Manager</option>
          <option value="employee"<?php if ($role === 'employee') echo 'selected'; ?>>Employee</option>
        </select>
      </div>

      <div class="d-flex justify-content-between">
        <a href="manage_users.php" class="btn btn-outline-secondary">Back</a>
        <button type="submit" class="btn btn-primary">Create User</button>
      </div>
    </form>
  </div>
</div>

<?php include 'footer.php'; ?>
